const { test, expect } = require('@playwright/test');

const baseURL = 'http://localhost:3000';
const password = 'AccountTest123!';

function uniqueEmail(prefix) {
  return prefix + '-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8) + '@example.test';
}

async function fillRegistration(page, email, firstPassword, repeatPassword = firstPassword) {
  const questionsLoaded = page.waitForResponse(
    response => response.url().includes('/api/SecurityQuestions/') && response.ok()
  );
  await page.goto('/#/register');
  await questionsLoaded;
  await page.locator('#emailControl').fill(email);
  await page.locator('#passwordControl').fill(firstPassword);
  await page.locator('#repeatPasswordControl').fill(repeatPassword);
  await page.locator('#securityQuestionControl').focus();
  await page.locator('#securityQuestionControl').press('Enter');
  await expect(page.getByRole('option').first()).toBeVisible();
  await page.getByRole('option').first().click();
  await page.locator('#securityAnswerControl').fill('playwright-answer');
}

async function registerInUI(page, email, accountPassword = password) {
  await fillRegistration(page, email, accountPassword);
  await page.locator('#registerButton').click();
  await expect(page).toHaveURL(/#\/login$/);
}

async function createAccount(request) {
  const account = { email: uniqueEmail('account'), password };
  const response = await request.post('/api/Users/', { data: account });
  expect(response.status()).toBe(201);
  return account;
}

async function loginInUI(page, account) {
  await page.goto('/#/login');
  await page.locator('#email').fill(account.email);
  await page.locator('#password').fill(account.password);
  await page.locator('#loginButton').click();
  await expect(page).toHaveURL(/#\/search$/);
}

async function logoutInUI(page) {
  await page.locator('#navbarAccount').click();
  await page.locator('#navbarLogoutButton').click();
  await page.locator('#navbarAccount').click();
  await expect(page.locator('#navbarLoginButton')).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(page.locator('#navbarLoginButton')).toBeHidden();
}

async function openChangePassword(page) {
  await page.goto('/#/privacy-security/change-password');
  await expect(page.locator('#password-form')).toBeVisible();
}

async function fillChangePassword(page, current, next) {
  await page.locator('#currentPassword').fill(current);
  await page.locator('#newPassword').fill(next);
  await page.locator('#newPasswordRepeat').fill(next);
  await page.locator('#changeButton').click();
}

function captchaAnswer(expression) {
  const match = expression.replace(/\s+/g, '').match(/^(\d+)([+*-])(\d+)([+*-])(\d+)$/);
  if (!match) throw new Error('Unexpected CAPTCHA expression: ' + expression);

  const numbers = [Number(match[1]), Number(match[3]), Number(match[5])];
  const operators = [match[2], match[4]];
  for (let i = 0; i < operators.length; i++) {
    if (operators[i] === '*') {
      numbers.splice(i, 2, numbers[i] * numbers[i + 1]);
      operators.splice(i, 1);
      i--;
    }
  }

  let result = numbers[0];
  for (let i = 0; i < operators.length; i++) {
    result = operators[i] === '+' ? result + numbers[i + 1] : result - numbers[i + 1];
  }
  return String(result);
}

async function prepareFeedback(page) {
  await page.goto('/#/contact');
  await expect(page.locator('#captcha')).toContainText(/\d+[+*-]\d+[+*-]\d+/);
  const answer = captchaAnswer(await page.locator('#captcha').innerText());
  await page.locator('#rating input').focus();
  await page.locator('#rating input').press('End');
  await page.locator('#captchaControl').fill(answer);
}

test.beforeEach(async ({ context }) => {
  await context.addCookies([
    { name: 'welcomebanner_status', value: 'dismiss', url: baseURL },
    { name: 'cookieconsent_status', value: 'accept', url: baseURL },
  ]);
});

test.describe('Регистрация', () => {
  test('reg-1: регистрация с уникальными email и паролем', async ({ page }) => {
    await registerInUI(page, uniqueEmail('reg1'));
  });

  test('reg-2: пустая форма не отправляется', async ({ page }) => {
    await page.goto('/#/register');
    await expect(page.locator('#registerButton')).toBeDisabled();
    await page.locator('#emailControl').focus();
    await page.locator('#passwordControl').focus();
    await expect(page.locator('mat-error').first()).toBeVisible();
  });

  test('reg-3: разные пароли вызывают ошибку', async ({ page }) => {
    await fillRegistration(page, uniqueEmail('reg3'), password, 'AnotherPass123!');
    await expect(page.locator('#registerButton')).toBeDisabled();
    await expect(page.locator('#repeatPasswordControl').locator('xpath=ancestor::mat-form-field[1]').locator('mat-error')).toBeVisible();
  });

  test('reg-4: повторная регистрация занятого email отклоняется', async ({ page }) => {
    const email = uniqueEmail('reg4');
    await registerInUI(page, email);
    await fillRegistration(page, email, password);
    await page.locator('#registerButton').click();
    await expect(page.locator('main [role="alert"]')).toHaveText(/\S/);
    await expect(page).toHaveURL(/#\/register$/);
  });

  test('reg-5: неверный email и короткий пароль не проходят проверку формы', async ({ page }) => {
    await fillRegistration(page, 'not-an-email', 'abc', 'abc');
    await expect(page.locator('#registerButton')).toBeDisabled();
    await expect(page.locator('#emailControl').locator('xpath=ancestor::mat-form-field[1]').locator('mat-error')).toBeVisible();
    await expect(page.locator('#passwordControl').locator('xpath=ancestor::mat-form-field[1]').locator('mat-error')).toBeVisible();
  });
});

test.describe('Вход и выход', () => {
  test('login-1: вход с верными данными', async ({ page, request }) => {
    const account = await createAccount(request);
    await loginInUI(page, account);
    await page.locator('#navbarAccount').click();
    await expect(page.locator('#navbarLogoutButton')).toBeVisible();
  });

  test('login-2: неверный email при верном пароле не даёт войти', async ({ page, request }) => {
    const account = await createAccount(request);
    await page.goto('/#/login');
    await page.locator('#email').fill('wrong-' + account.email);
    await page.locator('#password').fill(account.password);
    await page.locator('#loginButton').click();
    await expect(page.locator('main [role="alert"]')).toHaveText(/\S/);
    await expect(page).toHaveURL(/#\/login$/);
  });

  test('login-3: выход завершает сеанс', async ({ page, request }) => {
    const account = await createAccount(request);
    await loginInUI(page, account);
    await logoutInUI(page);
  });
});

test.describe('Смена пароля', () => {
  test('change-1: новый пароль совпадает с текущим и принимается', async ({ page, request }) => {
    const account = await createAccount(request);
    await loginInUI(page, account);
    await openChangePassword(page);
    await fillChangePassword(page, account.password, account.password);
    await expect(page.locator('main [role="status"]')).toBeVisible();
  });

  test('change-2: неверный текущий пароль отклоняется', async ({ page, request }) => {
    const account = await createAccount(request);
    await loginInUI(page, account);
    await openChangePassword(page);
    await fillChangePassword(page, 'WrongCurrent123!', 'NewAccount123!');
    await expect(page.locator('main [role="alert"]')).toBeVisible();
  });

  test('change-3: после смены пароля можно войти с новым', async ({ page, request }) => {
    const account = await createAccount(request);
    await loginInUI(page, account);
    await openChangePassword(page);
    const newPassword = 'NewAccount123!';
    await fillChangePassword(page, account.password, newPassword);
    await expect(page.locator('main [role="status"]')).toBeVisible();
    await logoutInUI(page);
    await loginInUI(page, { email: account.email, password: newPassword });
  });
});

test.describe('Обратная связь', () => {
  test('feedback-1: авторизованный пользователь отправляет отзыв', async ({ page, request }) => {
    const account = await createAccount(request);
    await loginInUI(page, account);
    await prepareFeedback(page);
    await page.locator('#comment').fill('Playwright account feedback');
    await expect(page.locator('#submitButton')).toBeEnabled();
    await page.locator('#submitButton').click();
    await expect(page.locator('#comment')).toHaveValue('');
    await expect(page.locator('mat-snack-bar-container').last()).toBeVisible();
  });

  test('feedback-1b: гость не должен отправлять отзыв по требованию', async ({ page }) => {
    await prepareFeedback(page);
    await page.locator('#comment').fill('Anonymous account feedback');
    await expect(page.locator('#submitButton')).toBeDisabled();
  });
  test('feedback-2: пустой комментарий не отправляется', async ({ page, request }) => {
    const account = await createAccount(request);
    await loginInUI(page, account);
    await prepareFeedback(page);
    await page.locator('#comment').focus();
    await page.locator('#captchaControl').focus();
    await expect(page.locator('#submitButton')).toBeDisabled();
    await expect(page.locator('#comment').locator('xpath=ancestor::mat-form-field[1]').locator('mat-error')).toBeVisible();
  });
});